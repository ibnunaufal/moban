@extends('layouts.defaults')
@section('content')
<script src="{{ URL::asset('js/auth.js') }} "></script>
<script src="{{ URL::asset('js/admin.js') }} "></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css">
<script src="https://code.jquery.com/jquery-3.5.1.js"></script> 
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"> defer</script>
<script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>

<script src="https://cdn.jsdelivr.net/gh/linways/table-to-excel@v1.0.4/dist/tableToExcel.js"></script>

<script>
firebase.auth().onAuthStateChanged(function(user) {
  if (!user){
    window.location.replace("./");
    alert('Silahkan Login Dahulu!');
    /// Kalau belum login langsung disuruh balek login lagi
  }
});
</script>
    <div class="content">
        <div class="row">
          <div class="col-12">
            <div class="alert alert-info">
              <button type="button" aria-hidden="true" class="close" data-dismiss="alert" aria-label="Close">
                <i class="tim-icons icon-simple-remove"></i>
              </button>
              <span>Halo Selamat Datang Admin!</span>
            </div>
                <div class="card card-chart">
                    <div class="card-header ">
                        <div class="row">
                            <div class="col-sm-6 text-left">
                              <h2 class="card-title"><b>Moban Admin Page</b></h2>
                              <h4 class="card-title">
                                Setting yang digunakan pada Arduino :
                              </h4>
                            </div>
                            <div class="col-sm-6">
                            <!-- data-toggle="modal" data-target="#exampleModal2" -->
                              <button id="btn1" onClick="opensetting()" class="btn btn-sm btn-info btn-simple float-right">Edit Setting</button>
                              <button id="btn2" onClick="canceledit()" class="btn btn-sm btn-info btn-simple float-right">Batal</button>
                              <button id="btn3" onClick="updateUser()" class="btn btn-sm btn-info btn-simple float-right">Simpan</button>
                              <script>document.getElementById('btn2').style.display = "none";</script>
                              <script>document.getElementById('btn3').style.display = "none";</script>
                            </div>
                        </div>
                    </div>
                    <div class="card-header ">
                        <div class="row">
                            <div class="col-sm text-left">
                                <div class="card-body">
                                  <div class="table-responsive">
                                  <form id="formupdate" method="POST" class="form horizontal" action="">
                                    <table class="table tablesorter bg-dark" id="">
                                      <thead class=" text-primary bg-info">
                                        <tr>
                                          <th>
                                            Name
                                          </th>
                                          <th>
                                            Value
                                          </th>
                                        </tr>
                                      </thead>
                                      <tbody>
                                        <tr>
                                          <td>
                                            Tinggi Sensor
                                          </td>
                                          <td>
                                            <!-- <input type="text" id="tinggisp"> -->
                                            <input type="number" id="tinggiinp" width="10" disabled class="form-control" min=1 max=200>
                                            <!-- <span id="tinggisp"></span> -->
                                          </td>
                                        </tr>
                                        <tr>
                                          <td>
                                            Lebar
                                          </td>
                                          <td>
                                            <!-- <span id="lebarsp"></span> -->
                                            <input type="number" id="lebarinp" disabled class="form-control" min=1 max=100>
                                          </td>
                                        </tr>
                                        <tr>
                                          <td>
                                            Panjang
                                          </td>
                                          <td>
                                            <!-- <span id="panjangsp"></span> -->
                                            <input type="number" id="panjanginp" disabled class="form-control" min=1 max=100>
                                          </td>
                                        </tr>
                                        <tr>
                                          <td>
                                            Delay
                                          </td>
                                          <td>
                                            <!-- <span id="delaysp"></span> -->
                                            <input type="number" id="delayinp" disabled class="form-control" min=1 max=100>
                                          </td>
                                        </tr>
                                      </tbody>
                                    </table>
                                    </form>
                                  </div>
                                </div>
                            </div>
                            <div class="col-sm text-left">
                                <div class="card-body">
                                  <div class="table-responsive">
                                    <table class="table tablesorter table-dark" id="settingtable">
                                      <thead class=" text-primary bg-info">
                                        <tr>
                                          <th>
                                            Name
                                          </th>
                                          <th>
                                            Value
                                          </th>
                                        </tr>
                                      </thead>
                                      <tbody>
                                        <tr>
                                          <td>
                                            Status 1
                                          </td>
                                          <td>
                                            <!-- <span id="stat1sp"></span> -->
                                            <input type="number" disabled id="stat1inp" class="form-control" min=1 max=100>
                                          </td>
                                        </tr>
                                        <tr>
                                          <td>
                                            Status 2
                                          </td>
                                          <td>
                                            <!-- <span id="stat2sp"></span> -->
                                            <input type="number" disabled id="stat2inp" class="form-control" min=1 max=100>
                                          </td>
                                        </tr>
                                        <tr>
                                          <td>
                                            Status 3
                                          </td>
                                          <td>
                                            <!-- <span id="stat3sp"></span> -->
                                            <input type="number" disabled id="stat3inp" class="form-control" min=1 max=100>
                                          </td>
                                        </tr>

                                      </tbody>
                                    </table>
                                  </div>
                                </div>
                                
                                <div class="alert alert-info">
                                  <button type="button" aria-hidden="true" class="close" data-dismiss="alert" aria-label="Close">
                                    <i class="tim-icons icon-simple-remove"></i>
                                  </button>
                                  <span>Klik Edit Setting untuk mengubah</span>
                                </div>
                            </div>
                        </div>                
                    </div>
            </div>
          <div class="row">
            <div class="col-12">
              <div class="card ">
                  <div class="card-header">
                    <div class="row">
                      <div class="col-sm-6 text-left">
                        <h4 class="card-title"> Kritik Saran</h4>
                      </div>
                      <div class="col-sm-6">
                        <div class="input-group">
                          <select class="custom-select" id="inputGroupSelect04">
                            <option selected>Choose...</option>
                            <option value="1">One</option>
                            <option value="2">Two</option>
                            <option value="3">Three</option>
                          </select>
                          <div class="input-group-append">
                            <button class="btn btn-sm btn-info btn-simple float-right" type="button">Button</button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="card-body">
                    <div class="table-responsive">
                    <table class="table tablesorter " id="sarantable">
                        <thead class=" text-primary">
                          <th>Tanggal</th>
                          <th>Jam</th>
                          <th>Nama</th>
                          <th>Email</th> 
                          <th>Jenis</th> 
                          <th style="width:30%">Saran</th> 
                        </thead>
                        <tbody id="saranbody">
                        </tbody>
                      </table> 
                    </div>
                  </div>
              </div>
            </div>
          </div>

          <div class="row" id="lengkap">
            <div class="col-lg-6 col-md-12">
              <div class="card ">
                <div class="card-header">
                  <div class="row">
                    <div class="col-sm-4 text-left">
                      <h4 class="card-title"> Debit Air Sungai</h4>
                      
                    </div>
                    <div class="col-sm-8">
                      <div class="input-group">
                        <select class="custom-select" id="cmbjumlahdebit">
                          <option class="text-dark" value="0">Semua Data</option>
                          <option class="text-dark" value="10">10 Data</option>
                          <option class="text-dark" value="50">50 Data</option>
                          <option class="text-dark" value="100">100 Data</option>
                        </select>
                        <select class="custom-select" id="cmbascdescdebit">
                          <option class="text-dark" value="asc">Ascending</option>
                          <option class="text-dark" value="desc">Descending</option>
                        </select>
                        <div class="input-group-append">
                          <button class="btn btn-sm btn-info btn-simple float-right" onclick="debittampil()" type="button">Tampilkan</button>
                        </div>
                      </div>
                      <button class="btn btn-sm btn-info btn-simple float-right" onclick="exportF(3)" type="button">Cetak Data</button>
                    </div>
                  </div>
                </div>
                <div class="card-body">
                  <div class="table-responsive">
                  <table class="table tablesorter debittable" id="debittable">
                      <thead class=" text-primary">
                        <th>Nomor</th>
                        <th>Tanggal</th>
                        <th>Jam</th>
                        <th>Ketinggian</th>
                        <th>Debit</th> 
                      </thead>
                      <tbody id="tbody1">
                      </tbody>
                    </table> 
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-6 col-md-12">
              <div class="card ">
                <div class="card-header">
                  <div class="row">
                    <div class="col-sm-4 text-left">
                      <h4 class="card-title"> Curah Hujan</h4>
                    </div>
                    <div class="col-sm-8">
                      <div class="input-group">
                        <select class="custom-select" id="cmbjumlahhujan">
                          <option class="text-dark" value="0">Semua Data</option>
                          <option class="text-dark" value="10">10 Data</option>
                          <option class="text-dark" value="50">50 Data</option>
                          <option class="text-dark" value="100">100 Data</option>
                        </select>
                        <select class="custom-select" id="cmbascdeschujan">
                          <option class="text-dark" value="asc">Ascending</option>
                          <option class="text-dark" value="desc">Descending</option>
                        </select>
                        <div class="input-group-append">
                          <button class="btn btn-sm btn-info btn-simple float-right" onclick="hujantampil()" type="button">Tampilkan</button>
                        </div>
                      </div>
                      <button class="btn btn-sm btn-info btn-simple float-right" onclick="exportF(4)" type="button">Cetak Data</button>
                    </div>
                  </div>
                </div>
                <div class="card-body">
                  <div class="table-responsive">

                    <table class="table tablesorter " id="ex-table">
                      <thead class=" text-primary">
                        <th>Nomor</th>
                        <th>Tanggal</th>
                        <th>Jam</th>
                        <th>Data Hujan</th>
                      </thead>
                      <tbody id="tbody2">
                      </tbody>
                    </table> 
                    <!-- <table class="table tablesorter " id="table1">
                      <thead class=" text-primary">
                        <tr>
                          <th>
                            Name
                          </th>
                          <th>
                            Country
                          </th>
                          <th>
                            City
                          </th>
                          <th class="text-center">
                            Salary
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                      <div id="isitbody1">
                      </div>
                        <tr>
                          <td>
                            Dakota Rice
                          </td>
                          <td>
                            Niger
                          </td>
                          <td>
                            Oud-Turnhout
                          </td>
                          <td class="text-center">
                            $36,738
                          </td>
                        </tr>
                        <tr>
                          <td>
                            Minerva Hooper
                          </td>
                          <td>
                            Curaçao
                          </td>
                          <td>
                            Sinaai-Waas
                          </td>
                          <td class="text-center">
                            $23,789
                          </td>
                        </tr>
                        
                      </tbody>
                    </table> -->
                  </div>
                </div>
              </div>
            </div>
          </div>
          
        
    </div>
    
    <!-- Modal -->
    <div class="modal fade" id="exampleModal2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content bg-dark">
            <div class="modal-header">
              <h5 class="modal-title text-light" id="exampleModalLabel">Edit Setting</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
                <form id="formupdate" method="POST" class="form horizontal" action="">
                  <div class="form-group text-light">
                      <label for="tinggiinp">Tinggi (cm) :</label>
                      <input type="number" id="tinggiinp" width="10" class="form-control" min=1 max=200>
                  </div>
                  <div class="form-group text-light">
                      <label for="lebarinp">Lebar (cm) :</label>
                      <input type="number" id="lebarinp" class="form-control" min=1 max=100>
                  </div>
                  <div class="form-group text-light">
                      <label for="panjanginp">Panjang (cm) :</label>
                      <input type="number" id="panjanginp" class="form-control" min=1 max=100>
                  </div>
                  <div class="form-group text-light">
                      <label for="stat1inp">Status 1 (cm) :</label>
                      <input type="number" id="stat1inp" class="form-control" min=1 max=100>
                  </div>
                  <div class="form-group text-light">
                      <label for="stat2inp">Status 2 (cm) :</label>
                      <input type="number" id="stat2inp" class="form-control" min=1 max=100>
                  </div>
                  <div class="form-group text-light">
                      <label for="stat3inp">Status 3 (cm) :</label>
                      <input type="number" id="stat3inp" class="form-control" min=1 max=100>
                  </div>
                  <div class="form-group text-light">
                      <label for="delayinp">Delay (menit) :</label>
                      <input type="number" id="delayinp" class="form-control" min=1 max=100>
                  </div>
              </form>  
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              <input type="button" class="btn btn-primary updateUser" name="signin" id="btnupdate" value="Click Here" onclick="updateUser();"/>
              <!-- <button type="button" class="btn btn-primary updateUser" name="signin" id="btnupdate">Save Changes</button> -->
            </div>
          </div>
        </div>
      </div>
@endsection