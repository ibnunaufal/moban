@extends('layouts.defaults')
@section('content')
<h1>We are Sorry</h1><h1>Mohon Maaf</h1>
<h3>This site is under going maintenance.</h3>
<h3>Website sedang dalam perbaikan.</h3>

@endsection