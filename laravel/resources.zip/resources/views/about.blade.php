@extends('layouts.defaults')
@section('content')
    <div class="content">
        <div class="row">
            <div class="col-12">
                <div class="card card-chart">
                    <div class="card-header ">
                        <div class="row">
                            <div class="col-sm-6 text-left">
                            <h2 class="card-title"><b>Tentang Aplikasi</b></h2>
                            </div>
                        </div>                
                    </div>
                    <div class="card-header">
                        <div class="row">
                            <div class="col-sm-8 text-left">
                                <h4 class="card-title">
                                    <p>
                                        Aplikasi MOBAN (Monitoring Debit banjir & Curah Hujan) merupakan aplikasi 
                                        yang dapat memantau Debit sungai dan Curah Hujan. Kedua hal ini merupakan parameter penting
                                        pada mitigasi bencana baik itu banjir maupun tanah longsor. 
                                    </p>
                                    <br>
                                    <p>
                                        Tak dapat dipungkiri,
                                        kurangnya informasi mengenai mitigasi bencana menjadi faktor penting dalam peringatan dini terhadap  
                                        potensi bencana yang akan terjadi dan dalam waktu singkat. Aplikasi ini menjadi salah satu solusi
                                        guna mengurangi kerugian maupun korban. Informasi yang diberikan berupa data realtime disampaikan  
                                        melalui infografis yang menarik dan mudah dipahami
                                    </p>
                                </h4>
                            </div>      
                            <div class="col-sm-4 text-center">
                                <img style="width:200px;height:200px;" src="{{ URL::asset('img/logo-moban-white.png') }}" alt="logo">
                                <img src="{{ URL::asset('img/tulisan.png') }}" alt="logo">
                            </div>
                        </div>                
                    </div>
                </div>

                <div class="card card-chart">
                    <!-- <div class="card-header ">
                    <div class="row">
                        <div class="col-sm-6 text-left">
                            <h2 class="card-title"><b>Dapatkan Notifikasi</b></h2>
                        </div>
                    </div>                
                    </div> -->
                    <div class="card-header ">
                    <div class="row">     
                        <div class="col-sm-8 text-left">
                            <h2 class="card-title"><b>Dapatkan Notifikasi</b></h2>
                            <h4 class="card-title">
                                <p>
                                    Dapatkan Notifikasi pada Gawai anda setiap kali potensi bencana datang. Unduh Aplikasi Moban-Android
                                    pada Google Play Store dengan memasukkan kata kunci Moban Android. 
                                </p>
                                <br>
                                <p>
                                    Setelah terunduh, aktifkan Notifikasi pada Aplikasi dalam menu Setting. Notifikasi berupa pesan dan
                                    nada akan muncul otomatis ketika potensi bencana datang.
                                </p>
                            </h4>
                            <img style="width:50%;" src="{{ URL::asset('img/gplay.png') }}" alt="gplay"><br>
                        </div> 
                        <div class="col-sm-4 text-center">
                            <img src="{{ URL::asset('img/mobanphone.jpg') }}" alt="mobanphone"><br>
                        </div>
                    </div>                
                    </div>
                </div>

                <div class="card card-chart">
                    <div class="card-header ">
                        <div class="row">
                            <div class="col-sm-6 text-left">
                            <h2 class="card-title"><b>Team</b></h2>
                            </div>
                        </div>                
                    </div>
                    <div class="card-header ">
                        <div class="row">
                            <div class="col-sm-8 text-left">
                                <h4 class="card-title">
                                    <p>
                                        Sistem ini dibuat dalam rangka menyelesaikan Tugas Akhir Program Studi Teknik Informatika
                                        Jurusan Teknik Elektro Politeknik Negeri Semarang.
                                    </p>
                                    <br>
                                    <p>
                                        
                                    </p>
                                </h4>
                            </div>      
                            <div class="col-sm-4 text-center">
                                <img style="width:200px;height:200px;" src="{{ URL::asset('img/logo-moban-white.png') }}" alt="logo">
                                <img src="{{ URL::asset('img/tulisan.png') }}" alt="logo">
                            </div>
                        </div>                
                    </div>
                </div>


            </div>
        </div>
    </div>
@endsection